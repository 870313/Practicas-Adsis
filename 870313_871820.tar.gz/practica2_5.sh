#!/bin/bash
#871820, Fabra Roque, Pablo Nicolas T 1 A
#870313, González Pardo, Juan T 1 A
echo -n "Introduzca el nombre de un directorio: "
read camino
if [ ! -d "$camino" ]; then
	echo "$camino no es un directorio"
	exit 1
else 
 
	num_files=$(ls "$camino" -p | grep -v / | wc -l)
	num_dirs=$(ls "$camino" -p | grep / | wc -l)
	echo "El numero de ficheros y directorios en $camino es de $num_files y $num_dirs, respectivamente"
fi
