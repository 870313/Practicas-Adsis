#!/bin/bash
#870313, Gonzalez Pardo, Juan, T,1,A
#871820, Fabra Roque, Pablo Nicolas T,1,A
echo -n "Introduzca el nombre del fichero: "
read nomFich 

if [ -e "$nomFich" ]; then
	echo -n "Los permisos del archivo $nomFich son: "
	if [ -r "$nomFich" ]; then
		echo -n "r"
	else
		echo -n "-"
	fi
	if [ -w "$nomFich" ]; then
		echo -n "w"
	else 
		echo -n "-"
	fi
	if [ -x "$nomFich" ]; then 
		echo -n "x"
	else 
		echo -n  "-"
	fi
else 
	echo "$nomFich no existe"
fi

