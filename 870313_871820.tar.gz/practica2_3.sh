#!/bin/bash
#871820, Fabra Roque, Pablo Nicolas, T,1,A
#870313, González Pardo, Juan T,1,A
if [ "$#" -ne 1 ]; then
	echo "Sintaxis: practica2_3.sh <nombre_archivo>"
	exit 1
fi
if [ -f "$1" ]; then 
       chmod ug+x "$1"
	stat -c%A "$1"
else 
	echo "$1 no existe"
fi	

