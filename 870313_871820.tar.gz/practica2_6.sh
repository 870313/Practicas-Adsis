#!/bin/bash
#871820, Fabra Roque, Pablo Nicolas, T,1,A
#870313, González Pardo, Juan, T,1,A

#buscamos los directorios que cumplan la condicion
candidatos=$(ls -p "$HOME" | grep "bin[a-zA-Z0-9][a-zA-Z0-9][a-zA-Z0-9]/" | wc -l)

#si no existe un directorio que cumpla con los requisitos , cremos uno
if [ $candidatos -eq 0 ]; then
	dir=$(mktemp -d "$HOME/binXXX")
	echo "Se ha creado el directorio $dir"
	echo "Directorio destino de copia: $dir"
#Si existe mas de un directorio, escogemos el mas reciente
else 
	ultimo=0
	for aux in $(ls -p "$HOME" | grep "bin[a-zA-Z0-9][a-zA-Z0-9][a-zA-Z0-9]/"); do
		masReciente=$(stat -c %Y "$HOME/$aux")
		if [ $masReciente -gt $ultimo ]; then
			ultimo=$masReciente
			aux2="$HOME/$aux"
			dir=$(echo "$aux2" | cut -c 1-$((${#aux2}-1)))
		fi
	done
	echo "Directorio destino de copia: $dir"
fi

#Copio todos los archivos que son ejecutables y no son directorios
numCopias=0
for aux1 in *; do
	if [ -x "$aux1" ]; then
		if [ ! -d "$aux1" ]; then
			echo "./$aux1 ha sido copiado a $dir"
			cp "$aux1" "$dir"
			numCopias=$((numCopias+1))
		fi
	fi
done

#Sacamos por pantalla el numero de ficheros copiados 
if [ $numCopias -eq 0 ]; then 
	echo "No se ha copiado ningun archivo"
else 
	echo "Se han copiado $numCopias archivos"
fi

