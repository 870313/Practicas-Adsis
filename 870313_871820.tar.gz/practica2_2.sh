#!/bin/bash 
#871820,Fabra Roque, Pablo Nicolas, T,1,A
#870313,Gonzalez Pardo,Juan,T,1,A
if [ $# -eq o ]; then
	exit 1
fi
for archivo in "$@"; do 
	if [ -f "$archivo" ]; then
		more "$archivo"
	else
		echo "$archivo no es un fichero"
	fi
done

