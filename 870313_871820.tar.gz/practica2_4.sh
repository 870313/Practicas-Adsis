#!/bin/bash
#871820, Fabra Roque, Pablo Nicolas, T, 1, A
#870313, González Pardo, Juan, T, 1, A
echo -n "Introduzca una tecla: "
read -n 1 tecla

if [[ $tecla =~ [[:digit:]] ]]; then
	echo -e "\n$tecla es un numero"
elif [[ $tecla =~ [[:alpha:]] ]]; then
	echo -e "\n$tecla es una letra"
else
	echo -e "\n$tecla es un caracter especial"
fi
